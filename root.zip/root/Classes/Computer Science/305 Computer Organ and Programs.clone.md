# 305 Computer Organ and Programs
This is a clone of a note. Go to its [primary location](../Cyber%20Operations/305%20Computer%20Organ%20and%20Program.md).