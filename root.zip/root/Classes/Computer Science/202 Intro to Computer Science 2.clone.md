# 202 Intro to Computer Science 2
This is a clone of a note. Go to its [primary location](../Cyber%20Operations/202%20Intro%20to%20Computer%20Science%20.md).