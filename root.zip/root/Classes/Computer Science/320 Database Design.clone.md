# 320 Database Design
This is a clone of a note. Go to its [primary location](../Cyber%20Operations/320%20Database%20Design.md).