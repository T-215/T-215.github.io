# 405 Operating Systems and Computer Architecture 
This is a clone of a note. Go to its [primary location](../Cyber%20Operations/405%20Operating%20Systems%20and%20Comp.md).