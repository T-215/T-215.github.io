# LDRS 371 Junior Leadership Seminar
This is a clone of a note. Go to its [primary location](../Core/LDRS%20371%20Junior%20Leadership%20Sem.md).