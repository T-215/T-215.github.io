# 495 Senior Seminar
This is a clone of a note. Go to its [primary location](../Cyber%20Operations/495%20Senior%20Seminar.md).